# SQL Business Insights Case

## Problem
Executive team needs revenue, margin and customer insights to guide targeting and pricing decisions.

## Data
Relational model (orders, order_items, customers, products, calendar). Include ERD and data dictionary.

## Approach
- Data model review and KPI definitions
- Core SQL: CTEs, window functions, cohorting, funnels
- Performance: indexes, query plans (EXPLAIN), constraints

## Deliverables
- `/sql/` key queries (revenue, margin, cohorts, funnels)
- `/docs/` ERD + KPI glossary
- `/outputs/` CSVs and charts

## Business Insights
- Revenue/margin trends with drivers
- Cohort retention & repeat purchase
- Funnel conversion bottlenecks and actions
