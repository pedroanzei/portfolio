# End‑to‑End BI Case

## Scope
Mini data pipeline → SQL model → Python analysis → Power BI dashboard.

## Architecture
- Ingest: Python (ETL) from CSV/API
- Store/Model: PostgreSQL/MySQL
- Transform: SQL views/CTEs (dbt‑style optional)
- Visualize: Power BI

## Deliverables
- `/etl/` scripts
- `/sql/` views and KPIs
- `/bi/` Power BI model + report
- `/docs/` runbook and KPI definitions
