# Executive Power BI Dashboard

## Audience
C‑level and Directors (Revenue, Profitability, Customers).

## Model
- Star schema (fact tables + conformed dimensions)
- DAX measures with clear naming and comments
- Role‑level security (optional)

## Pages
1) Executive Summary
2) Revenue & Margin
3) Customer & Retention
4) Product/Category
5) Geography

## Deliverables
- `.pbix` file
- `/model/` diagram + measure catalog
- `/screens/` png/jpg screenshots
