# Python Data Cleaning & EDA

## Goal
Turn a raw CSV into a reliable analytical dataset and extract actionable insights.

## Steps
1) Data audit (shape, missingness, anomalies)
2) Cleaning & standardization (types, outliers, business rules)
3) Feature engineering (dates, cohorts, segments)
4) EDA and narrative

## Deliverables
- `/notebooks/` EDA notebook
- `/data/` raw → cleaned
- `/reports/` executive summary

## Notes
Keep explanations concise and business‑oriented.
